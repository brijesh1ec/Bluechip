﻿using DBAccess.Services;
using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogic
{
    public class CourseService : ICourseService
    {
        private readonly ICourseDBService courseDBService;

        public CourseService(ICourseDBService courseDBService)
        {
            this.courseDBService = courseDBService;
        }

        public string AddCourse(Course course)
        {
            string result = string.Empty;
            if (course == null)
                throw new Exception("course should be blank or null");
            else
                try
                {
                    result = this.courseDBService.AddCourse(course);
                }
                catch (Exception ex)
                {

                    throw;
                }

            return result;
        }

        public List<Course> GetCourses()
        {
            return this.courseDBService.GetCourses();
        }
    }
}
