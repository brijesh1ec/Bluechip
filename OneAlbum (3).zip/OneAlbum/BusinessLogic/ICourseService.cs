﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLogic
{
    public interface ICourseService
    {
        List<Course> GetCourses();
        string AddCourse(Course course);
    }
}
