﻿using System;
using Entity;

namespace BusinessLogic
{
    public interface IStudentService
    {
        string RegisterStudent(Registeration enroll);

    }
}
