﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;
using DBAccess.Services;

namespace BusinessLogic
{
    public class StudentService : IStudentService
    {
        private readonly DBAccess.Services.IStudentService studentService;
        public StudentService(DBAccess.Services.IStudentService studentService)
        {
            this.studentService = studentService;
        }

        public string RegisterStudent(Registeration enroll)
        {
            string result = string.Empty;
            if (enroll == null)
                throw new Exception("Enter valid Registration");

            try
            {
                result = this.studentService.RegisterStudent(enroll);
            }
            catch (Exception ex)
            {

            }

            return result;
        }
    }
}
