﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBAccess.EntityMapping
{
    public class RegisterMapping
    {
        public const string RegisterStudent = "Usp_RegisterStudent";
    }
}
