﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBAccess.Model
{
    public class UserRole
    {
        public int EmployeeId { get; set; }
        public string Email { get; set; }

        public string Menu { get; set; }
        public string RoleName { get; set; }
        public int RoleID { get; set; }
        public bool IsActive { get; set; }



    }

    public static class UserRoles
    {
        public const string Admin = "ADMIN";
        public const string User = "User";
        public const string Manager = "Manager";
    }

    public class Company
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Country { get; set; }
        public List<Employee> Employees { get; set; } = new List<Employee>();
    }
}
