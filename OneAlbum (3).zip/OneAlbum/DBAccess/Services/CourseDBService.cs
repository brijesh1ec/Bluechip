﻿using Entity.Mapping;
using Entity;
using System;
using System.Collections.Generic;
using System.Text;
using Dapper;

namespace DBAccess.Services
{
    public class CourseDBService : ICourseDBService
    {
        private readonly DapperContext _dbContext;
        private readonly IDapper _dapper;

        public CourseDBService(IDapper dapper)
        {
            _dapper = dapper;
        }

        public string AddCourse(Course course)
        {
            if (course == null)
                throw new Exception($"Please enter a valid Course");

            Course course1 = null;
            var parameters = new Dictionary<string, object>();
            parameters.Add(CourseMapping.CourseName, course.CourseName);
            DynamicParameters dbParams = new DynamicParameters();
            dbParams.AddDynamicParams(parameters);
            try
            {
                course1 = this._dapper.Insert<Course>(CourseMapping.AddCourse, dbParams, System.Data.CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {

                throw;
            }


            return Convert.ToString(course1.ID);
        }

        public List<Course> GetCourses()
        {
            List<Course> courses = new List<Course>();
            courses = this._dapper.GetAll<Course>(CourseMapping.GetAllCourse, null, System.Data.CommandType.StoredProcedure);
            return courses;
        }
    }
}
