﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBAccess.Services
{
    public interface ICourseDBService
    {

        List<Course> GetCourses();
        string AddCourse(Course course);
    }
}
