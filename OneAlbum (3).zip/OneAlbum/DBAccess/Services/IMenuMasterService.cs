﻿using DBAccess.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBAccess.Services
{
    public interface IMenuMasterService
    {
        IEnumerable<Menu> GetMenuMaster();
        IEnumerable<Menu> GetMenuMaster(String UserRole);
    }
}
