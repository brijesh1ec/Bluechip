﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBAccess.Services
{
    public interface IStudentService
    {
        string RegisterStudent(Registeration enroll);
    }
}
