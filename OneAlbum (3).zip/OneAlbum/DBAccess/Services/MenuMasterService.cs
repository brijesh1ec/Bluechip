﻿using DBAccess.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace DBAccess.Services
{
    public class MenuMasterService : IMenuMasterService
    {
        private readonly DapperContext _dbContext;
        private readonly IDapper _dapper;

        public MenuMasterService(DapperContext dbContext, IDapper dapper)
        {
            _dbContext = dbContext;
            _dapper = dapper;
        }

        public IEnumerable<Menu> GetMenuMaster()
        {
            List<Menu> menuList = new List<Menu>();
            try
            {
                //var dbparams = new DynamicParameters();
                //dbparams.Add("Id", data.Id, DbType.Int32);
                var procedure = "UspGetAllMenus";
                //using (var connection = _dbContext.CreateConnection())

                menuList = _dapper.GetAll<Menu>(procedure, null, commandType: CommandType.StoredProcedure);
                //using (var connection =_dapper.GetDbconnection())
                //{
                //    return _dapper.GetAll<Menu>();

                //        //(await connection.QueryAsync<Product>(procedure)).ToList();
                //}
                return menuList;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public IEnumerable<Menu> GetMenuMaster(string UserRole)
        {
            var result = default(List<Menu>);
            //_dbContext.MenuMaster.Where(m => m.User_Roll == UserRole).ToList();
            return result;
        }
    }
}
