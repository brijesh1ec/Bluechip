﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;
using DBAccess.EntityMapping;
using Dapper;
using System.Data;

namespace DBAccess.Services
{
    public class StudentService : IStudentService
    {
        private readonly DapperContext _dbContext;
        private readonly IDapper _dapper;

        public StudentService(DapperContext dbContext, IDapper dapper)
        {
            _dbContext = dbContext;
            _dapper = dapper;
        }

        public string RegisterStudent(Registeration registeration)
        {
            string result = string.Empty;
            var parameters = new Dictionary<string, object>();
            parameters.Add("Username", registeration.UserName);
            parameters.Add("Firstname", registeration.FirstName);
            parameters.Add("Lastname", registeration.LastName);
            parameters.Add("Password", registeration.Password);
            parameters.Add("Confirmpwd", registeration.Confirmpwd);
            parameters.Add("Email", registeration.Email);
            parameters.Add("DOB", registeration.Date_of_Birth);
            parameters.Add("Gender", registeration.Gender);
            parameters.Add("MaritalStatus", registeration.MaritalStatus);
            parameters.Add("Address", registeration.Address);

            DynamicParameters dbParams = new DynamicParameters();
            dbParams.AddDynamicParams(parameters);
            try
            {
                var res = _dapper.Insert<Registeration>(Entity.Mapping.RegisterMapping.RegisterStudent, dbParams, CommandType.StoredProcedure);
                result = Convert.ToString(res.ID);
                //Create SP and run application to store data to backend
            }
            catch (Exception ex)
            {

                throw;
            }
            return result;
        }
    }
}
