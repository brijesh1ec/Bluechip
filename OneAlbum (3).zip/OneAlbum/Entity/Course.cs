﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entity
{
    public class Course
    {
        [Display(Name = "ID")]
        public int ID { get; set; }

        //[Required(ErrorMessage = "Please enter Course Code")]
        [Display(Name = "Course Code")]
        public string CourseCode { get; set; }

        [Display(Name = "Course Inception")]
   
        [DataType(DataType.Date), DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = false)]
        public Nullable<System.DateTime> CourseDate { get; set; }

        [Required(ErrorMessage = "Please enter Course Name")]
        [Display(Name = "CourseName")]
        public string CourseName { get; set; }

        [Display(Name = "SelectedCourse")]
        public bool SelectedC { get; set; }
    }
}
