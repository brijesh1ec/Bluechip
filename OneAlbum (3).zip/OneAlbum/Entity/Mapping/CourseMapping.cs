﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity.Mapping
{
    public class CourseMapping
    {
        public const string AddCourse = "Usp_AddCourse";
        public const string GetAllCourse = "Usp_GetAllCourse";
        public const string CourseName = "CourseName";
    }
}
