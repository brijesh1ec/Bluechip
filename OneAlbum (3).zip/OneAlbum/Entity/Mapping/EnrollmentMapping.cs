﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity.Mapping
{
    public class EnrollmentMapping
    {
        public const string EnrollCouse = "Usp_EnrollCourse";
    }
}
