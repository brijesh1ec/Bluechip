﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity.Mapping
{
    public class RegisterMapping
    {
        public const string RegisterStudent = "Usp_UserRegistration";
        public const string RegisterID = "RegisterID";
    }
}
