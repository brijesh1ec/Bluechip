﻿using BusinessLogic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnePicture.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnePicture.Controllers
{
    public class CourseController : Controller
    {
        private readonly ICourseService courseService;

        public CourseController(ICourseService courseService)
        {
            this.courseService = courseService;
        }

        // GET: CourseController
        public ActionResult Index()
        {
            CourseViewModel courseViewModel = new CourseViewModel();
            courseViewModel.CourseList = this.courseService.GetCourses();
            return View(courseViewModel);
        }

        // GET: CourseController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: CourseController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Course/AddCourse")]
        public ActionResult Create([FromForm] CourseViewModel courseViewModel)
        {
            this.courseService.AddCourse(courseViewModel.Course);

            return View();
            //View("Index");
        }

        [HttpGet]
        //[HttpPost]
        [ValidateAntiForgeryToken]
        [Route("CourseEnroll")]
       // [ChildActionOnly]
        public ActionResult Enrollc()
        {
            //this.courseService.AddCourse(courseViewModel.Course);
            CourseViewModel cViewModel = new CourseViewModel();
            cViewModel.CourseList = this.courseService.GetCourses();

            return View("Course/EnrollCourse.cshtml", cViewModel);
            //View("Index");
        }

        [HttpGet]
        //[HttpPost]
        [ValidateAntiForgeryToken]
        [Route("EnrollCourse")]
        public ActionResult Enroll()
        {
            //this.courseService.AddCourse(courseViewModel.Course);
            CourseViewModel cViewModel = new CourseViewModel();
            cViewModel.CourseList = this.courseService.GetCourses();

            //return View("Course/Enroll.cshtml",cViewModel);
            return PartialView("StudentCourse.cshtml", cViewModel);
            //View("Index");
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //[Route("Course/EnrollCourse")]
        //public ActionResult Enroll([FromForm] CourseViewModel courseViewModel)
        //{
        //    //this.courseService.AddCourse(courseViewModel.Course);
        //    CourseViewModel cViewModel = new CourseViewModel();
        //    cViewModel.CourseList = this.courseService.GetCourses();

        //    return View();
        //    //View("Index");
        //}

        // POST: CourseController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CourseController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: CourseController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CourseController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: CourseController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
