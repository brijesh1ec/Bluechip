﻿using DBAccess.Model;
using DBAccess.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OnePicture.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;

namespace OnePicture.Controllers
{
    //[Authorize(Roles = UserRoles.Admin)]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IMenuMasterService _menuMasterService;
        const string roleType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";

        public HomeController(ILogger<HomeController> logger, IMenuMasterService menuMasterService)
        {
            _logger = logger;
            _menuMasterService = menuMasterService;
            var res = _menuMasterService.GetMenuMaster();

        }

        private string getClaimsFromToken(string token)
        {
            string userEmail = string.Empty;

            if (!string.IsNullOrEmpty(token))
            {
                //return Unauthorized();
            }
            var jwt = token;
            var handler = new JwtSecurityTokenHandler();
            var cliams = handler.ReadJwtToken(jwt);
            var email = cliams.Claims;
            if (cliams.Claims.Count() > 0)
                userEmail = cliams.Claims.ToList()[0].Value;
            userEmail = cliams.Claims.FirstOrDefault(t => t.Type.Equals(roleType)).Value;
            return userEmail;
        }
        [Authorize(Roles = UserRoles.Admin)]
        [HttpGet]
        public IActionResult Index()
        {
            var hd = Request.Cookies.ContainsKey("jwtCookie");
            // string   headerValue=
            var hdvalue = Request.Cookies.TryGetValue("jwtCookie", out var headerValue);
            string c = Convert.ToString(hd);
            var cl = getClaimsFromToken(headerValue);
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
