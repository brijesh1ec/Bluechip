﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace OnePicture.Controllers
{

    public class SignController : Controller
    {
        private readonly IConfiguration _configuration;

        public SignController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // GET: SignController
        //[Route("login")]
        public ActionResult Index()
        {

            try
            {
                var t = getToken();
                if (!string.IsNullOrEmpty(t))
                    SetJWTCookie(t);
            }
            catch (Exception ex)
            {

                throw;
            }
            return View();
        }

        // GET: SignController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: SignController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SignController/Create

        [ValidateAntiForgeryToken]
        [HttpPost]

        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SignController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: SignController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SignController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SignController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }


        private string GenerateJSONWebToken()
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("MynameisJamesBond007"));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                 //issuer: "https://www.yogihosting.com",
                 //audience: "https://www.yogihosting.com",
                 issuer: "http://localhost:4200",
                audience: "http://localhost:51943",
                expires: DateTime.Now.AddHours(3),
                signingCredentials: credentials
                );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private void SetJWTCookie(string token)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddHours(3),
            };
            Response.Cookies.Append("jwtCookie", token, cookieOptions);
        }

        private string getToken()
        {
            string email = "iam@gmail.com";

            List<string> userRoles = new List<string> { "ADMIN", "User", "Manager" };
            var userRole = userRoles.Where(r => r.Equals("Admin", StringComparison.OrdinalIgnoreCase)).ToList();

            var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, email),
                    new Claim(ClaimTypes.Role, userRole[0].ToString()),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                };

            //foreach (var userRole in userRoles)
            //{
            //    authClaims.Add(new Claim(ClaimTypes.Role, userRole));
            //}

      

            var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));

            var token = new JwtSecurityToken(
                issuer: _configuration["JWT:ValidIssuer"],
                audience: _configuration["JWT:ValidAudience"],
                expires: DateTime.Now.AddHours(3),
                claims: authClaims,
                signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                );

            string tokenkey = new JwtSecurityTokenHandler().WriteToken(token);

            return tokenkey;
            //return Ok(new
            //{
            //    token = new JwtSecurityTokenHandler().WriteToken(token),
            //    expiration = token.ValidTo
            //});
        }
    }
}
