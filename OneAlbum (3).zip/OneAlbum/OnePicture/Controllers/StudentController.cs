﻿using BusinessLogic;
using Entity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnePicture.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnePicture.Controllers
{
    public class StudentController : Controller
    {
        private readonly BusinessLogic.IStudentService studentService;
        private const string NewStudent = "Student created successfully";
        string result = string.Empty;

        public StudentController(IStudentService studentService)
        {
            this.studentService = studentService;
        }

        // GET: StudentController
        public ActionResult Index()
        {
            ViewBag.Message = $"{Convert.ToString(TempData["Res"])} { NewStudent}";
            return View();
        }

        // GET: StudentController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: StudentController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StudentController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        //public ActionResult Create(IFormCollection collection
        public ActionResult Create([FromForm] EnrollViewModel enrollViewModel)
        {

            try
            {
                //object ViewModel = Activator.CreateInstance(EnrollViewModel);
                //if (TryUpdateModelAsync(EnrollViewModel))
                //{
                //    // save the ViewModel
                //    this.studentService.RegisterStudent(enrollViewModel.EnrollStudent);
                //}

                if (ModelState.IsValid)
                {

                    result = this.studentService.RegisterStudent(enrollViewModel.EnrollStudent);
                    return RedirectToAction(nameof(Index));
                }

                TempData["Res"] = result;

                // return View();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: StudentController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: StudentController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
