﻿using Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnePicture.Models
{
    public class EnrollViewModel
    {
        public Registeration EnrollStudent { get; set; }
        public List<Registeration> Enrollsinfo { get; set; }
    }
}
